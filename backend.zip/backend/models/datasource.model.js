class Datasource {
  name;
  dataConnectionName;
  method;
  url;
  headers;
  params;
  body;

  constructor() {
    this.headers = [];
    this.params = [];
  }
}
