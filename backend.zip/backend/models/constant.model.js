const DATA_PATH = "./backend/data";
const SUCCESS_DATA_UPLOAD = {
  status: "success",
  message: "Data uploaded successfully!",
};
const SUCCESS_DATA_DELETE = {
  status: "success",
  message: "Delete successful!",
};
const SUCCESS_STATUS = {
  status: "success",
};
const FAILED_STATUS = {
  status: "failed",
};

exports.DATA_PATH = DATA_PATH;
exports.SUCCESS_DATA_UPLOAD = SUCCESS_DATA_UPLOAD;
exports.SUCCESS_DATA_DELETE = SUCCESS_DATA_DELETE;
exports.SUCCESS_STATUS = SUCCESS_STATUS;
exports.FAILED_STATUS = FAILED_STATUS;
