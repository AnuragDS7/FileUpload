class Layout {
  rows;
  columns;
  panelDetails;

  constructor() {
    this.panelDetails = [];
  }
}

module.exports = Layout;
