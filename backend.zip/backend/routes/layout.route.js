const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const layoutFolder = `${DATA_PATH}/layout`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(layoutFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "Layouts not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:layoutName", (req, res, next) => {
  try {
    let { layoutName } = req.params;
    let layoutRawData = fs.readFileSync(`${layoutFolder}/${layoutName}.json`);
    let layoutJson = JSON.parse(layoutRawData);
    if (layoutJson) {
      res.status(200).json(layoutJson);
    } else {
      res.status(404).json({ message: "Layout data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:layoutName", (req, res, next) => {
  try {
    let { layoutName } = req.params;
    let layoutJson = req.body;

    fs.writeFileSync(
      `${layoutFolder}/${layoutName}.json`,
      JSON.stringify(layoutJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:layoutName", (req, res, next) => {
  try {
    let { layoutName } = req.params;

    fs.rmSync(`${layoutFolder}/${layoutName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
