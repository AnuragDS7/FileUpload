const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const dataConnectionFolder = `${DATA_PATH}/data-connection`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(dataConnectionFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "Data Connections not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:dataConnectionName", (req, res, next) => {
  try {
    let { dataConnectionName } = req.params;
    let dataConnectionRawData = fs.readFileSync(
      `${dataConnectionFolder}/${dataConnectionName}.json`
    );
    let dataConnectionJson = JSON.parse(dataConnectionRawData);
    if (dataConnectionJson) {
      res.status(200).json(dataConnectionJson);
    } else {
      res.status(404).json({ message: "Data Connection data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:dataConnectionName", (req, res, next) => {
  try {
    let { dataConnectionName } = req.params;
    let dataConnectionJson = req.body;

    fs.writeFileSync(
      `${dataConnectionFolder}/${dataConnectionName}.json`,
      JSON.stringify(dataConnectionJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:dataConnectionName", (req, res, next) => {
  try {
    let { dataConnectionName } = req.params;

    fs.rmSync(`${dataConnectionFolder}/${dataConnectionName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
