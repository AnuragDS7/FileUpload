const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const viewFolder = `${DATA_PATH}/view`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(viewFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "views not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:viewName", (req, res, next) => {
  try {
    let { viewName } = req.params;
    let viewRawData = fs.readFileSync(`${viewFolder}/${viewName}.json`);
    let viewJson = JSON.parse(viewRawData);
    if (viewJson) {
      res.status(200).json(viewJson);
    } else {
      res.status(404).json({ message: "view data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:viewName", (req, res, next) => {
  try {
    let { viewName } = req.params;
    let viewJson = req.body;

    fs.writeFileSync(
      `${viewFolder}/${viewName}.json`,
      JSON.stringify(viewJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:viewName", (req, res, next) => {
  try {
    let { viewName } = req.params;

    fs.rmSync(`${viewFolder}/${viewName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
