const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const dashboardFolder = `${DATA_PATH}/dashboard`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(dashboardFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "dashboards not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:dashboardName", (req, res, next) => {
  try {
    let { dashboardName } = req.params;
    let dashboardRawData = fs.readFileSync(
      `${dashboardFolder}/${dashboardName}.json`
    );
    let dashboardJson = JSON.parse(dashboardRawData);
    if (dashboardJson) {
      res.status(200).json(dashboardJson);
    } else {
      res.status(404).json({ message: "dashboard data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:dashboardName", (req, res, next) => {
  try {
    let { dashboardName } = req.params;
    let dashboardJson = req.body;

    fs.writeFileSync(
      `${dashboardFolder}/${dashboardName}.json`,
      JSON.stringify(dashboardJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:dashboardName", (req, res, next) => {
  try {
    let { dashboardName } = req.params;

    fs.rmSync(`${dashboardFolder}/${dashboardName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
