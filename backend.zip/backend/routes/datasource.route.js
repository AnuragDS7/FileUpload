const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const datasourceFolder = `${DATA_PATH}/datasource`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(datasourceFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "Datasources not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:datasourceName", (req, res, next) => {
  try {
    let { datasourceName } = req.params;
    let datasourceRawData = fs.readFileSync(
      `${datasourceFolder}/${datasourceName}.json`
    );
    let datasourceJson = JSON.parse(datasourceRawData);
    if (datasourceJson) {
      res.status(200).json(datasourceJson);
    } else {
      res.status(404).json({ message: "Datasource data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:datasourceName", (req, res, next) => {
  try {
    let { datasourceName } = req.params;
    let datasourceJson = req.body;

    fs.writeFileSync(
      `${datasourceFolder}/${datasourceName}.json`,
      JSON.stringify(datasourceJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:datasourceName", (req, res, next) => {
  try {
    let { datasourceName } = req.params;

    fs.rmSync(`${datasourceFolder}/${datasourceName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
