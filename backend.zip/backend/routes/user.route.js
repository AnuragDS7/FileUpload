const fs = require("fs");
const bcrypt = require("bcryptjs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
  SUCCESS_STATUS,
  FAILED_STATUS,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const userFolder = `${DATA_PATH}/user`;
const saltRounds = 10;

router.post("/authenticate", (req, res, next) => {
  try {
    let username = req.body.username;
    let plaintextPassword = req.body.password;
    if (username && plaintextPassword) {
      let userRawData = fs.readFileSync(`${userFolder}/${username}.json`);
      let userJson = JSON.parse(userRawData);
      let { password, ...userDetails } = userJson;
      bcrypt.compare(plaintextPassword, password, (err, result) => {
        if (result) {
          res.status(200).json({ ...SUCCESS_STATUS, userDetails: userDetails });
        } else {
          res.status(401).json(FAILED_STATUS);
        }
      });
    }
  } catch (ex) {
    res.status(500).json({ ...FAILED_STATUS, message: ex.message });
  }
});

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(userFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "user not found!" });
    }
  } catch (ex) {
    res.status(500).json({ ...FAILED_STATUS, message: ex.message });
  }
});

router.get("/:userName", (req, res, next) => {
  try {
    let { userName } = req.params;
    let userRawData = fs.readFileSync(`${userFolder}/${userName}.json`);
    let userJson = JSON.parse(userRawData);
    if (userJson) {
      res.status(200).json(userJson);
    } else {
      res.status(404).json({ message: "user data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ ...FAILED_STATUS, message: ex.message });
  }
});

router.post("/:userName", (req, res, next) => {
  try {
    let { userName } = req.params;
    let userJson = req.body;
    const plaintextPassword = userJson.password;
    bcrypt.hash(plaintextPassword, saltRounds, function (err, hash) {
      if (err) {
        res.status(500).json(FAILED_STATUS);
      }
      // Update password with the hashed password
      userJson.password = hash;

      fs.writeFileSync(
        `${userFolder}/${userName}.json`,
        JSON.stringify(userJson)
      );
      res.status(200).json(SUCCESS_DATA_UPLOAD);
    });
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ ...FAILED_STATUS, message: ex.message });
  }
});

router.delete("/:userName", (req, res, next) => {
  try {
    let { userName } = req.params;

    fs.rmSync(`${userFolder}/${userName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ ...FAILED_STATUS, message: ex.message });
  }
});

module.exports = router;
