const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const controlFolder = `${DATA_PATH}/control`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(controlFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "Controls not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:controlName", (req, res, next) => {
  try {
    let { controlName } = req.params;
    let controlRawData = fs.readFileSync(
      `${controlFolder}/${controlName}.json`
    );
    let controlJson = JSON.parse(controlRawData);
    if (controlJson) {
      res.status(200).json(controlJson);
    } else {
      res.status(404).json({ message: "Control data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:controlName", (req, res, next) => {
  try {
    let { controlName } = req.params;
    let controlJson = req.body;

    fs.writeFileSync(
      `${controlFolder}/${controlName}.json`,
      JSON.stringify(controlJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:controlName", (req, res, next) => {
  try {
    let { controlName } = req.params;

    fs.rmSync(`${controlFolder}/${controlName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
