const fs = require("fs");
const path = require("path");
const {
  DATA_PATH,
  SUCCESS_DATA_UPLOAD,
  SUCCESS_DATA_DELETE,
} = require("../models/constant.model");
const express = require("express");
const router = express.Router();

const linkedviewFolder = `${DATA_PATH}/linked-view`;

router.get("", (req, res, next) => {
  try {
    let allFiles = fs.readdirSync(linkedviewFolder);
    let jsonFiles = [];
    allFiles.forEach((file) => {
      if (path.extname(file) == ".json") {
        jsonFiles.push(file.slice(0, file.length - 5));
      }
    });

    if (jsonFiles) {
      res.status(200).json(jsonFiles.sort((a, b) => a - b));
    } else {
      res.status(404).json({ message: "Linked views not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.get("/:linkedviewName", (req, res, next) => {
  try {
    let { linkedviewName } = req.params;
    let linkedviewRawData = fs.readFileSync(`${linkedviewFolder}/${linkedviewName}.json`);
    let linkedviewJson = JSON.parse(linkedviewRawData);
    if (linkedviewJson) {
      res.status(200).json(linkedviewJson);
    } else {
      res.status(404).json({ message: "Linked view data not found!" });
    }
  } catch (ex) {
    res.status(500).json({ message: ex.message });
  }
});

router.post("/:linkedviewName", (req, res, next) => {
  try {
    let { linkedviewName } = req.params;
    let viewJson = req.body;

    fs.writeFileSync(
      `${linkedviewFolder}/${linkedviewName}.json`,
      JSON.stringify(viewJson)
    );
    res.status(200).json(SUCCESS_DATA_UPLOAD);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

router.delete("/:linkedviewName", (req, res, next) => {
  try {
    let { linkedviewName } = req.params;

    fs.rmSync(`${linkedviewFolder}/${linkedviewName}.json`);
    res.status(200).json(SUCCESS_DATA_DELETE);
  } catch (ex) {
    //console.log(ex);
    res.status(500).json({ message: ex.message });
  }
});

module.exports = router;
