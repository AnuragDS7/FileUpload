const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const path = require("path");

const layoutRoute = require("./routes/layout.route");
const dataConnectionRoute = require("./routes/data-connection.route");
const datasourceRoute = require("./routes/datasource.route");
const viewRoute = require("./routes/view.route");
const controlRoute = require("./routes/control.route");
const dashboardRoute = require("./routes/dashboard.route");
const roleRoute = require("./routes/role.route");
const testDataRoute = require("./routes/test-data.route");
const linkedviewRoute = require("./routes/linked-view.route");
const userRoute = require("./routes/user.route");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/", express.static(path.join(__dirname, "dcc-configurator")));
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, DELETE, PUT, PATCH, OPTIONS"
  );
  next();
});

app.use("/api/layout", layoutRoute);
app.use("/api/data-connection", dataConnectionRoute);
app.use("/api/datasource", datasourceRoute);
app.use("/api/view", viewRoute);
app.use("/api/control", controlRoute);
app.use("/api/dashboard", dashboardRoute);
app.use("/api/role", roleRoute);
app.use("/api/test-data", testDataRoute);
app.use("/api/linked-view", linkedviewRoute);
app.use("/api/user", userRoute);
app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "dcc-configurator", "index.html"));
});

module.exports = app;
